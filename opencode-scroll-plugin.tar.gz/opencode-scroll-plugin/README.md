# opencode-scroll-plugin

Plugin para [Zellij](https://zellij.dev/) que melhora a experiência de scroll ao usar o **OpenCode** — especialmente útil quando logs longos de build/deploy "fogem" do buffer.

---

## Funcionalidades

| Tecla | Ação |
|-------|------|
| `u` / `PageUp` | Scroll rápido +10 linhas para cima |
| `d` / `PageDown` | Scroll rápido +10 linhas para baixo |
| `↑` / `↓` | Scroll linha a linha |
| `g` / `Home` | Pula para o topo do buffer |
| `G` / `End` | Pula para o final (modo "follow") |
| `/` | Abre barra de busca |
| `c` | Limpa o lock de erro e volta ao final |

- **Detecção automática de modo OpenCode**: o plugin só ativa os atalhos quando o pane focado tem "opencode" no título.
- **Auto-lock em erros**: se keywords como `ERROR`, `FAIL`, `panic` aparecem no buffer, o scroll trava no topo e exibe aviso em vermelho.

---

## Requisitos

- Rust toolchain estável
- `wasm32-wasi` target:
  ```bash
  rustup target add wasm32-wasi
  ```
- Zellij ≥ 0.42

---

## Build e instalação

```bash
chmod +x build.sh
./build.sh
```

O script compila o `.wasm` e copia para `~/.config/zellij/plugins/`.

---

## Uso

### Carregamento manual (rápido)

```bash
zellij run --plugin file:~/.config/zellij/plugins/opencode-scroll-plugin.wasm
```

### Via layout (recomendado)

```bash
zellij --layout layout/opencode.kdl
```

Isso abre o OpenCode no painel principal e o plugin como barra de status na base.

---

## Como funciona

O plugin assina os eventos `PaneUpdate` e `Key` da API do Zellij:

- **`PaneUpdate`**: verifica se o pane focado tem "opencode" no título e ativa o modo de scroll aprimorado.
- **`Key`**: intercepta as teclas de scroll customizadas e chama as funções nativas do Zellij (`scroll_up`, `scroll_down`, `scroll_to_top`, `scroll_to_bottom`).
- **Render**: exibe uma barra de status de 1–2 linhas com o estado atual (seguindo / offset / erro detectado).

---

## Estrutura do projeto

```
opencode-scroll-plugin/
├── Cargo.toml
├── build.sh
├── src/
│   └── lib.rs          # Plugin principal
└── layout/
    └── opencode.kdl    # Layout Zellij pronto para uso
```
